/*
Owen McCooey Capak
SNHU - CS210  
Prof. Mill
05/21/2022
Project One - Chada Tech
*/


#include <iostream> // standard I/O library
#include <iomanip> // parametric manipulators
#include <windows.h> // system library for clearing screen, exiting program.
using namespace std;
// displays menu for optional actions
void displayMenu() {
	cout << "---------------------------\n";
	cout << "| 1 - Add One Hour" << setw(10) << "|\n";
	cout << "| 2 - Add One Minute" << setw(9) << " | \n";
	cout << "| 3 - Add One Second" << setw(9) << " | \n";
	cout << "| 4 - Exit Program" << setw(11) << " | \n";
	cout << "---------------------------\n";
	cout << "Please Enter 1-4: ";
}

void selectionExec(int& clockHr12, int& clockMin12, int& clockSec12, int& clockHr24, int& clockMin24, int& clockSec24) {
	bool exitLoop = false; // used in conjuction with our while loop
	int userSelection = 0;
	displayMenu(); // call menu
	
	while (!exitLoop) {
		cin >> userSelection; // userinput
		// menu actions for adding 1 to hr, min, or sec.
		switch (userSelection) {
		case 1:
			++clockHr24;
			++clockHr12;
			exitLoop = true;
			break;
		case 2:
			++clockMin24;
			++clockMin12;
			exitLoop = true;
			break;
		case 3:
			++clockSec24;
			++clockSec12;
			exitLoop = true;
			break;
		case 4:
			exitLoop = true;
			exit(0); // exits the program
			break;
		default: // invalid input, will loop back
			cout << "Please enter a valid selection" << endl;
			cout << "Please Enter 1-4: ";
			cin >> userSelection;
			// clears invalid input from Line to avoid infinite loop
			cin.clear();
			cin.ignore(1000, '\n');
			exitLoop = false;
			break;
		}
	}
}
/*
* function with if statements to keep the correct hours, mins, and secs.
* includes pass by references to set new values for veriables in main function
*/
void clockRules(int& clockHr12, int& clockMin12, int& clockSec12,
	int& clockHr24, int& clockMin24, int& clockSec24, string& ampm) {
	if (clockSec12 >= 60) {
		clockSec12 = 0;
		++clockMin12;
	}
	if (clockSec24 >= 60) {
		clockSec24 = 0;
		++clockMin24;
	}
	if (clockMin12 >= 60) {
		clockMin12 = 0;
		clockSec12 = 0;
		++clockHr12;
	}
	if (clockMin24 >= 60) {
		clockMin24 = 0;
		clockSec24 = 0;
		++clockHr24;
	}
	if (clockHr12 >= 12) {
		ampm = (ampm == "AM") ? "PM" : "AM"; //set AM or PM when reaching 12 hrs for 12 - Hour Clock
	}
	if (clockHr24 >= 24) {
		clockHr24 = 0;
		clockMin24 = 0;
		clockMin24 = 0;
	}
	if (clockHr12 >= 12) {
		clockHr12 = 0;
		clockMin12 = 0;
		clockSec12 = 0;
	}
}
int main() {
	// variables for hrs, mins, and secs
	int twelveClockHr = 0;
	int twelveClockMin = 0;
	int twelveClockSec = 0;
	int twenty4ClockHr = 0;
	int twenty4ClockMin = 0;
	int twenty4ClockSec = 0;
	string AMPM = "AM";
	bool programExit = false;
	// Loop to display clocks with updated time for each loop
	while (!programExit) {
		while (!GetAsyncKeyState(VK_ESCAPE)) { // escape key press exit loop and return to the menu
				// print out of the clocks in text format.
			cout << setfill('-') << setw(25) << "";
			cout << setfill(' ') << setw(5) << "";
			cout << setfill('-') << setw(25) << "" << endl;
			cout << setfill(' ');
			cout << "| 12-Hour Clock | " << setw(4) << "";
			cout << "| 24-Hour Clock | " << endl;
			cout << "| " << setfill('0') << setw(2) << right << twelveClockHr << ":";
			cout << setw(2) << right << twelveClockMin << ":";
			cout << setw(2) << right << twelveClockSec << " " << AMPM << " ";
			cout << setfill(' ') << setw(5) << "";
			cout << "| " << setfill('0') << setw(2) << right << twenty4ClockHr << ":";
			cout << setw(2) << right << twenty4ClockMin << ":";
			cout << setw(2) << right << twenty4ClockSec << " | " << endl;
			cout << setfill(' ');
			cout << setfill('-') << setw(25) << "";
			cout << setfill(' ') << setw(5) << "";
			cout << setfill('-') << setw(25) << "" << endl;
			cout << setfill(' ');
			// add 1 sec to the clocks every loop
			++twelveClockSec;
			++twenty4ClockSec;
			
			clockRules(twelveClockHr, twelveClockMin, twelveClockSec,
				twenty4ClockHr, twenty4ClockMin, twenty4ClockSec, AMPM);
			Sleep(1000); // Delay each loop for 1 sec
			system("CLS"); // clears the screen when each loop ends
		}
		// calls selectionExec while sending main variables values
		selectionExec(twelveClockHr, twelveClockMin, twelveClockSec,
			twenty4ClockHr, twenty4ClockMin, twenty4ClockSec);
	}
	programExit = true; // boolean for loop check
	return 0;
}

